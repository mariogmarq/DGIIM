touch tests//.timeout
CMD=" /home/mario/Documentos/MP/NetBeans/tiles_2/dist/Debug/GNU-Linux/tiles_2  -open data/OPEN_ERROR.data 1> tests//.out9 2>&1"
eval $CMD
rm tests//.timeout
