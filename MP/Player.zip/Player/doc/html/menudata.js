var menudata={children:[
{text:"Página principal",url:"index.html"},
{text:"Clases",url:"annotated.html",children:[
{text:"Lista de clases",url:"annotated.html"},
{text:"Índice de clases",url:"classes.html"},
{text:"Miembros de las clases",url:"functions.html",children:[
{text:"Todo",url:"functions.html"},
{text:"Funciones",url:"functions_func.html"}]}]},
{text:"Archivos",url:"files.html",children:[
{text:"Lista de archivos",url:"files.html"},
{text:"Miembros de los ficheros",url:"globals.html",children:[
{text:"Todo",url:"globals.html"},
{text:"Funciones",url:"globals_func.html"}]}]}]}
