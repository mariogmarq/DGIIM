#!/bin/bash
# Author: Luis Castillo Vidal L.Castillo@decsai.ugr.es
VERSION=1.0
# Load configuration & moves to the project root folder
if [ -d scripts ]
then
    source scripts/doConfig.sh
else
    source doConfig.sh
fi
clear
if [ -z "$(ls -A $TESTS_FOLDER/*.test)" ]
then
    echo "NO TESTS AVAILABLE"
    exit
fi
printf "${WHITE}Generating fresh binaries\n${GRAY}"
make build
printf "${WHITE}\n"
# Marks to parse .test files
CALL_MARK="%%%CALL"
OUTPUT_MARK="%%%OUTPUT"
VALGRIND_MARK="%%%VALGRIND"
# Prebuild the command line for the call 
DIST=dist/Debug/GNU-Linux/
BINARY=$(ls $DIST)
# Auxiliary files
# .out* Raw output of the run
# .due* Expected predefined output
# .real* Real predefined output
# .fail* Output of every failed test
# Flag to detect FAILED tests
FAILED_TESTS=NO
k=1
for test in $TESTS_FOLDER/*.test
do
    # Parse the codes for the call
    if grep --quiet $CALL_MARK $test; # Cond1
    then 
        MYCALL=$(grep $CALL_MARK $test | sed s/$CALL_MARK//)
        # Parse the expected output from the test
        DUE_OUTPUT=$(sed -n /$OUTPUT_MARK/,\$p $test)
        # Parse possible  Valgrind request
        if  grep --quiet $VALGRIND_MARK $test; 
        then
            FORCE_VALGRIND=YES
        else
            FORCE_VALGRIND=NO
        fi
        # Compose the call and execute it
        if [ $USE_VALGRIND == "YES" ] || [ $FORCE_VALGRIND == "YES" ]
        then 
            VALGRIND="valgrind --leak-check=full "
            FULL_BINARY=$VALGRIND$PROJECT_FOLDER/$DIST/$BINARY
            eval "$FULL_BINARY $MYCALL &> $TESTS_FOLDER/.out$k"
            # If Valgrind is requested, an additional check is carried out
            # to llok for possible memory leaks
            VALGRIND_OUTPUT="\n        "$(grep "ERROR SUMMARY" $TESTS_FOLDER/.out$k | sed s/==[0-9]*==//)
            if grep "ERROR SUMMARY" $TESTS_FOLDER/.out$k | grep --quiet " 0 errors";
            then 
                VALGRIND_LEAKS=FALSE
            else
                VALGRIND_LEAKS=TRUE
            fi
        else
            VALGRIND=""
            FULL_BINARY=$VALGRIND$PROJECT_FOLDER/$DIST/$BINARY
            eval "$FULL_BINARY $MYCALL &> $TESTS_FOLDER/.out$k"
            VALGRIND_OUTPUT=""
            VALGRIND_LEAKS=FALSE
        fi
        # If the real output of the program cotains %%%OUTPUT marks, then only those marks
        # are compared for validity. Otherwise, the full output is compared
        if  grep --quiet $OUTPUT_MARK $TESTS_FOLDER/.out$k; 
        then
            REAL_OUTPUT=$(grep -v == $TESTS_FOLDER/.out$k | sed -n /$OUTPUT_MARK/,\$p )
        else
            REAL_OUTPUT=$(echo  $OUTPUT_MARK; grep -v == $TESTS_FOLDER/.out$k)
        fi
        # Save due and real outputs in disk for further use
        echo "$DUE_OUTPUT" > $TESTS_FOLDER/.due$k
        echo "$REAL_OUTPUT" > $TESTS_FOLDER/.real$k
        # When both outputs (expected and real) differ or valgrind detects leaks of memory
        # the test FAILS
        if [ ! "$DUE_OUTPUT" == "$REAL_OUTPUT" ] || [ "$VALGRIND_LEAKS" == "TRUE" ]
        then
            printf  "${RED}[FAILED] Test #$k [$test] ($VALGRIND $BINARY $MYCALL) $VALGRIND_OUTPUT\n"
            cp $TESTS_FOLDER/.out$k $TESTS_FOLDER/.fail$k
            FAILED_TESTS=YES
        else
            printf  "${GREEN}[  OK  ] Test #$k [$test] ($VALGRIND $BINARY $MYCALL) $VALGRIND_OUTPUT\n"
        fi
    fi # Cond 1
    k=$[k + 1]
done 
printf "${WHITE}\n"
if [ "$FAILED_TESTS" == "YES" ]
then 
    echo "Press [y] to review FAILED REPORTS, other to skip"
    read REVIEW
    if [ "$REVIEW" == "y" ]
    then
        clear        
        for test in $TESTS_FOLDER/.fail*
        do
            NUMBER=$(echo $test | sed s/^.*fail//)
            printf "\n${RED}FAILED Test $test \n${GRAY}"
            cat $test
            printf "\n${WHITE}Differences found betweem ${GREEN}DUE${WHITE} and ${RED}REAL${WHITE} outputs:\n${GRAY}"
            DIFF=$(diff $TESTS_FOLDER/.due$NUMBER $TESTS_FOLDER/.real$NUMBER | sed s/^\>/'\\033[0;31m'\>/ | sed s/^\</'\\033[0;32m'\</ | sed s/$/'\\033[1;30m'/)
            printf "$DIFF"
            printf "\n"
        done 
    fi
fi
# Remove auxiliary files
rm -f $TESTS_FOLDER/.out* $TESTS_FOLDER/.due* $TESTS_FOLDER/.real* $TESTS_FOLDER/.fail*
printf "\n${WHITE}"
