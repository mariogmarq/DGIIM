var searchData=
[
  ['extract',['extract',['../classBag.html#ac75abe2b7626e50109a1add3382978af',1,'Bag']]]
];
