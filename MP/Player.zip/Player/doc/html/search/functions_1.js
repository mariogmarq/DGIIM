var searchData=
[
  ['define',['define',['../classBag.html#ad380d36f2628b3ffe0ca19cfe53d7c19',1,'Bag']]]
];
